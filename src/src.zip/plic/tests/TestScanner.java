package plic.tests;

import plic.analyse.AnalyseurLexical;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Objects;

public class TestScanner {

    public static void main(String[] args) throws FileNotFoundException {
        File file = new File("src/plic/sources/Plic0D.plic");

//        AnalyseurLexical analyseurLexical = new AnalyseurLexical(file);
//        String mot = analyseurLexical.next();
//        while (!Objects.equals(mot, "EOF")) {
//            System.out.println(mot);
//            mot = analyseurLexical.next();
//        }
//        System.out.println("EOF");


    }

}
